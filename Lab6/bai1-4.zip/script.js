//===================Bài 1===================
const uppercaseString = (string) => {
    return string.toUpperCase();
}
const lowercaseString = (string) => {
    return string.toLowerCase();
}
export{uppercaseString, lowercaseString};
// ==================Bài 2====================
export const stringFunctinons = {
    uppercaseString: function(str){
        return str.toLowerCase();
    },  
    lowercaseString: function(str){
        return  str.toLowerCase();
    },
};