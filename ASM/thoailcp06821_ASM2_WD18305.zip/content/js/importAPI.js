// page1.js

import { loadHeader, loadFooter, loadBanner, loadHeaderIndex, loadFooterIndex} from './apiLoader.js';
loadHeader();
loadBanner();
loadFooter();
loadHeaderIndex();
loadFooterIndex();
