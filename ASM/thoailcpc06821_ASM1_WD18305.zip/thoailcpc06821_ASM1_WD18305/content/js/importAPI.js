// page1.js

import { loadHeader, loadFooter, loadBanner, } from './apiLoader.js';

// Gọi hàm để tải header và footer
loadHeader();
loadBanner();
loadFooter();

